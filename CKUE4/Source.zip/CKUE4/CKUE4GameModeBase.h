// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "EngineMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "CKUE4GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class CKUE4_API ACKUE4GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
