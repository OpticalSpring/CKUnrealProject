// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerTankController.h"

void APlayerTankController::PostInitializeComponents()
{
	Super::PostInitializeComponents();
}

void APlayerTankController::OnPossess(APawn * aPawn)
{
	Super::OnPossess(aPawn);
}
