// Fill out your copyright notice in the Description page of Project Settings.


#include "TankWidget.h"
#include "TankCharacter.h"

void UTankWidget::BindCharacterStat(class UTankCharacter* NewCharacterStat) {
}
